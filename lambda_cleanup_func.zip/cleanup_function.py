import logging
import os

import boto3
from botocore.config import Config
from crhelper import CfnResource

helper = CfnResource(json_logging=False, log_level="INFO", boto_level="ERROR", sleep_on_delete=0)
logger = logging.getLogger(__name__)
boto3_config = Config(retries={"max_attempts": 60})

@helper.create
@helper.update
def no_op(_, __):
    pass

@helper.delete
def delete(event, _):
  # Delete all EC2 fleets assocaited with this Stack.
  region = os.environ["AWS_REGION"]
  session = boto3.session.Session(region_name=region)
  client = session.client("ec2")

  # Get all fleets tagged with this fleet.
  fleet_filters = [{"Name": "tag:StackID", "Values": [helper.StackId]}]
  describe_resp = client.describe_fleets(Filters=fleet_filters)

  for fleet in describe_resp["Fleets"]:
    fleet_id = fleet["FleetId"]
    session.delete_fleets(FleetIds=[fleet_id], TerminateInstances=True)

def handler(event, context):
  helper(event, context)
